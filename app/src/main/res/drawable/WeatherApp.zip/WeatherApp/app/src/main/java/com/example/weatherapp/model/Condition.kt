package com.example.weatherapp.model

data class Condition(
    val code: Int,
    val icon: String,
    val text: String
)