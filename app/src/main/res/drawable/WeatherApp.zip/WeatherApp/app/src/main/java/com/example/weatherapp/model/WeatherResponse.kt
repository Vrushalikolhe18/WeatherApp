package com.example.weatherapp.model

data class WeatherResponse(
    val current: Current,
    val location: Location
)